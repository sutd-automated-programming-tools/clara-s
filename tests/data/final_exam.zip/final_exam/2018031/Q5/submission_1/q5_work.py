class Person:
    def __init__( self, name = 'Unknown', age = 0, contact_details = {'phone': '+65 0000 0000', 'email': 'nobody@nowhere.com.sg' }):
        self.name = name
        self.age = age
        self.contact_details = contact_details
        
    def setX(self, name, age):
        if type(name) is str:
            if len(str(name)) >= 1:
                self._name = name
                return self._name
            else:
                pass
        elif type(age) is int:
            if age >= 0:
                self._age = age
                return self._age
            else:
                pass
        else: 
            pass
                
    def getX(self):
        return self._name, self._age