#####################
#Starter code for Q3#
#####################

def equity(f):
	
    receive=0
    pay=0
    for i in f:
        receive+=f[i][0]
    for j in f:
        pay+=f[j][1]
    equity=receive-pay
    return(receive,pay,equity)

############
#Test cases#
############
f1={'A': [100, 0], 'B': [100, 0], 'C': [100, 0]}
f2={'M': [30, 20], 'N': [50, 70], 'O': [60, 80]}
f3={'J': [0, 30], 'K': [0, 20], 'L': [0, 40]}

print(equity(f1))
print(equity(f2))
print(equity(f3))

