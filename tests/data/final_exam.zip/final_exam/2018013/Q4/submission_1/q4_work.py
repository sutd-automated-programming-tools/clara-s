# FINAL EXAM: QUESTION 4


def wordcount (s):
    s_list=s.split(' ')
    count=[len(s_list)]
    first=s_list[0]
    for i in s_list:
        
        for j in range(len(i)):
            if j=='\n':
                count[0]-=1
                count.append(1)
                break
        
        if i[-1]=='\n':
            count.append('None')
            
        
       
        
        return count

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 