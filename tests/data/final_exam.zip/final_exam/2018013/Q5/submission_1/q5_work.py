class Person:
    def __init__(self,name='Unknown',age=0,contact_details={'phone':'+65 0000 0000','email':'nobody@nowhere.com.sg'}):
        self.name=name
        self.age=age
        self.contact_details=contact_details
        
    def get_name(self):
        return self._name
    
    def set_name(self,new):
        if isinstance(new,str) and len(new)>=1:
            self._name=new
            
    def get_age(self):
        return self._age
    
    def set_age(self,value):
        if value>=0 and isinstance(value,int):
            self._age=value
            
    name=property(get_name,set_name)
    age=property(get_age,set_age)

    def get_email(self):
        return self._contact_details['email']
    
    def set_email(self,newemail):
        if isinstance(newemail,str):
            at=0
            for i in newemail:
                if i=='@':
                    at+=1
            if at==1:
                newlist=newemail.split('@')
                before=newlist[0]
                a=len(before)
                countb=0
                for i in before:
                    
                    if i=='.' or i=='_' or i.isalnum():
                        countb+=1
                if countb==a:
                    after=newlist[1]
                    b=len(after)
                    counta=0
                    for i in after:
                        
                        if i=='.' or i=='_' or i.isalnum():
                            counta+=1
                    if counta==b:
                        countdot=0
                        for i in after:
                            if i =='.':
                                countdot+=1
                        
                        if countdot>=1:
                            self._contact_details['email']=newemail
    email=property(get_email,set_email)