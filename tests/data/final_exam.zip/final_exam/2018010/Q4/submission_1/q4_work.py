# FINAL EXAM: QUESTION 4


from collections import defaultdict
def wordcount(s):
    punc = [':',';',',','.','-']
    ans = []
    for item in punc:
        s = s.replace(item,'')

    s = s.split('\n')
    ncount = len(s) # number of lines
    if len(s) == 1:
        dic = defaultdict(int)
        smallls = s[0].split()
        for item in smallls:
            dic[item] += 1
        ans.append(len(dic.keys()))
        return ans
    
    for line in s:
        dic = defaultdict(int)
        if line == ' ':
            dic[' '] = None
        smallls = line.split()
        for item in smallls:
            dic[item] += 1
        if dic == {}:
            ans.append(None)
        else:
            ans.append(len(dic.keys()))
        
    return ans

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 