#Qns 5
class Person:
    def __init__(self, name = 'Unknown', age = 0, contact_details = {'phone':'+65 0000 0000', 'email':'nobody@nowhere.com.sg'}, mother = None):
        self._name = name
        self._age = age
        self.contact_details = contact_details
        self._mother = mother
        
    def getname(self):
        return self._name
    def setname(self, new):
        if len(new) > 0:
            if isinstance(new, str):
                self._name = new
    def getage(self):
        return self._age
    def setage(self, new):
        if isinstance(new, int):
            if new >= 0:
                self._age = new
                
    name,age = property(getname,setname), property(getage,setage)
    
    
    def getemail(self):
        return self.contact_details['email']
    
    def setemail(self, new):
        
            
        newls = new.split('@')
        def checker(new):
            for item in new:
                for char in item:
                    if not char.isdigit() and not char.isalpha() and char != '.' and char != '_':
                        return False
            return True
        if len(newls) > 1:    
            if isinstance(new, str) and checker(newls) and '.' in newls[1]:
                self.contact_details['email'] = new
            
    email = property(getemail,setemail)
    
    def getmother(self):
        return self._mother
    def setmother(self, m):
        if m == None and type(m)== Person and m != self:
            self._mother = m
    mother = property(getmother, setmother)

    