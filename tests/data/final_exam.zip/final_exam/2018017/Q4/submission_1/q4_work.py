# FINAL EXAM: QUESTION 4


def wordcount (s):
    ls_of_ls = []
    ls1 = []
    ls2 = []
    ls3 = []
    ls4 = []
    ls5 = []
    ls6 = []
    ans = []
    new = s.replace("\n", " NEWLINE ")
    splitted_ls = new.split()
    print(splitted_ls)
    for word in splitted_ls:
        if word is not 'NEWLINE' and word not in ls1:
            ls1.append(word)
        elif word is not 'NEWLINE' and word in ls1:
            pass
        elif word is 'NEWLINE':
            ls2.append(word)
            break
        
        # use len(list) to find out number of distinct, unique words
        # use if/else statement with if len(list) > 0: ans.append(len(list)) to add the count to the final list, else ans.append(None)
        if len(list) > 0:
            ans.append(len(list))
        else:
            ans.append(None)

    return ans

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 