class Person:
    def __init__(self,name = "Unknown", age = 0, contact_details = {"phone":"+65 0000 0000", "email":"nobody@nowhere.com.sg"}):
        self._name = str(name)
        self._age = int(age)
        self.contact_details = contact_details
        
    def get_name(self):
#        print("Getter is called")
        return self._name
    
    def set_name(self, name):
#        print("Setter is called")
        if isinstance(name, str) and len(name) >= 1:
            self._name = name
        else:
            pass
        
    def get_age(self):
#        print("Getter is called")
        return self._age
    
    def set_age(self, age):
#        print("Setter is called")
        if isinstance(age, int) and age >= 0:
            self._age = age
        else:
            pass
        
    def get_email(self):
#        print("Getter is called")
        return self.contact_details["email"]
    
    def set_email(self, email):
#        print("Setter is called")
        valid_char = "qwertyuiopasdfghjklzxcvbnm._QWERTYUIOPASDFGHJKLZXCVBNM"
        
        #Condition 1
        cond_1 = isinstance(email, str)
        #Condition 2
        cond_2 = email.count("@") == 1
        #Condition 3
        for i in email:
            cond_3 = True
            if i == "@":
                pass
            elif i in valid_char:
                pass
            else: 
                cond_3 = False
        #Condition 4
        split_email = []
        for k in email:
            split_email.append(k)
        after_ls = []
        for j in split_email:
            if j is not "@":
                pass
            else:
                after_ls.append(j)
            cond_4 = "." in after_ls
        
        if cond_1 and cond_2 and cond_3 and cond_4:
            self.contact_details["email"] = email
        else:
            pass
            
    name = property(get_name, set_name)
    age = property(get_age, set_age)
    email = property(get_email, set_email)