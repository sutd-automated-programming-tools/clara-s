# FINAL EXAM: QUESTION 4


def wordcount(s):
    minus = 0
    newls1 = []
    newls2 = []
    testls = []
    ls = s.split('\n')
    for i in ls:
        x = i.split()
        newls1.append(x)
    for e in newls1:
        minus = 0
        for y in e:
            if e.count(y) > 1 and (e in testls) == False:
                testls.append(e)
                minus += 1
        if len(e)-minus == 0:
            newls2.append(None)
        else:
            newls2.append(len(e)-minus)
    return newls2

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 