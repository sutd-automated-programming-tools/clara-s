#####################
#Starter code for Q3#
#####################

def equity(f):
    tot_rec = 0
    tot_pay = 0
    for key in f:
        tot_rec += f[key][0]
        tot_pay += f[key][1]
    net_eq = tot_rec - tot_pay
    return (tot_rec, tot_pay, net_eq)

############
#Test cases#
############
f1={'A': [100, 0], 'B': [100, 0], 'C': [100, 0]}
f2={'M': [30, 20], 'N': [50, 70], 'O': [60, 80]}
f3={'J': [0, 30], 'K': [0, 20], 'L': [0, 40]}

print(equity(f1))
print(equity(f2))
print(equity(f3))

