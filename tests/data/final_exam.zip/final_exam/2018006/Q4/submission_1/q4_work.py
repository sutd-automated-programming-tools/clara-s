# FINAL EXAM: QUESTION 4


def wordcount(s):
    a = s.split()
    print(a)
    dictt = {}
    count = 0
    count_list = []
    for i in range(len(a)):
        if a[i] not in dictt:
            dictt[a[i]] = 1
            count += 1
        else:
            dictt[a[i]] += 1
            
    list_of_values = []
    for keys, values in dictt.items():
        list_of_values.append(values)
    return count

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 