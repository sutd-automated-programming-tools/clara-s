class Person:
    _name = ''
    _age = 0
    default_dict = {'phone': '+65 0000 0000', 'email': 'nobody@nowhere.com.sg'}
    _mother = None
    
    def __init__(self, name = 'Unknown', age = 0, contact_details = default_dict, mother = None):
        self.name = name
        self.age = age
        self.contact_details = contact_details
        self.mother = mother
    
    def get_name(self):
        return self._name
    
    def set_name(self, name):
        if type(name) == str and len(name) >= 1:
            self._name = name
        
    def get_age(self):
        return self._age
    
    def set_age(self, age):
        if type(age) == int and age >= 0:
            self._age = age
            
    def get_email(self):
        return self.contact_details['email']
        
    def set_email(self, new_email):
        correct = False
        if type(new_email) == str:
            if new_email.count('@') == 1:
                email1 = new_email.split('@') #[0]chicken, [1]floss.com.sg
                email2 = email1[0].split('.') #chicken
                for values in email2:
                    if values.isalpha() == True:
                        if email1[1].count('.') >= 1: #[1]floss.com.sg
                            email3 = email1[1].split('.')
#                            print(email3)
                            for values2 in email3:
#                                print(values2)
                                if values2.isalpha() == True:
                                    correct = True
                                
        if correct == True:
            self.contact_details['email'] = new_email
                    
    def get_mother(self):
        return self._mother
    
    def set_mother(self, mother_name):
        if mother_name == None or type(mother_name) is str:
            if mother_name != self._name:
                self._mother = mother_name
            
    name = property(get_name, set_name)
    age = property(get_age, set_age)
    email = property(get_email, set_email)
    mother = property(get_mother, set_mother)