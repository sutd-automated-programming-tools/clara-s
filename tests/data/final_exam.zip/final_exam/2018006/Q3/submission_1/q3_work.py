#####################
#Starter code for Q3#
#####################

def equity(f):
    total_receive = 0
    total_payable = 0
    for keys, values in f.items():
        total_receive += values[0]
        total_payable += values[1]
    total_equity = total_receive - total_payable
    return (total_receive, total_payable, total_equity)

############
#Test cases#
############
f1={'A': [100, 0], 'B': [100, 0], 'C': [100, 0]}
f2={'M': [30, 20], 'N': [50, 70], 'O': [60, 80]}
f3={'J': [0, 30], 'K': [0, 20], 'L': [0, 40]}

print(equity(f1))
print(equity(f2))
print(equity(f3))

