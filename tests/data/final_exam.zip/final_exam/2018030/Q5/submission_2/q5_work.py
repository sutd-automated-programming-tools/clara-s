class Person:
        def __init__(self,name="Unknown",age=0,contact_details={"phone":"+65 0000 0000", "email":"nobody@nowhere.com.sg"}):
        self._name = name
        self._age = age
        self._contact_details = contact_details
        
    def get_name(self):
        return self._name
    
    def set_name(self,name):
        if isinstance(name,str)==True and len(name) >= 1:
            self._name = name
        else:
            pass
    
    def get_age(self):
        return self._age
    
    def set_age(self,age):
        if isinstance(age,int)==True and age >= 0:
            self._age = age
        else:
            pass
        
    def get_contact_details(self):
        return self._contact_details
    
    def set_contact_details(self,contact_details):
        self._contact_details = contact_details
        
    def get_email(self):
        return self._contact_details["email"]
    
    def set_email(self,inp):
        count = 0
        dotcheck = 0
        for i in inp:
            if i == "@":
                count += 1
            if count == 1 and i == ".":
                dotcheck += 1
        if isinstance(inp,str) == True and count == 1 and dotcheck >= 1:
            self._email = inp
        else:
            pass
        
        
    name = property(get_name,set_name)
    age  = property(get_age,set_age)
    contact_details = property(get_contact_details,set_contact_details)
    email = property(get_email,set_email)