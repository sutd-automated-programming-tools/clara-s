# FINAL EXAM: QUESTION 4


def wordcount (s):
        w = s.replace(";"," ")
    w = w.replace(","," ")
    w = w.split("\n")
    count = 0
    output = []
    if len(w) == 1:
        x = w[0].split()
        for k in range(len(x)-1):            
            if k >= len(x)-1:
                pass
            else:
                if x[k] != x[k+1]:
                    count += 1
        count += 1
        output.append(count)
    else:                
        for i in range(len(w)):
            if i >= len(w)-1:
                h =w[i].split(" ")
                for m in range(len(h)-1):
                    if h[m] != h[m+1]:
                        count += 1
                count += 1
                output.append(count)
                count = 0
            else:
                if w[i] == "" or w[i] == ' ':
                    output.append(None)
                    count = 0
                elif w[i] != w[i+1]:
                    count += 1
                    if count != 0:
                        count += 1
                        output.append(count)
                        count = 0
    return output


print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 