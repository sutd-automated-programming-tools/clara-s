          

class Person:
    def __init__(self,name='Unknown',age=0,contact_details={'phone':'+65 0000 0000', 'email':'nobody@nowhere.com.sg'}):
        self.name=name
        self._name=name
        self.age=age
        self._age=age
        self.contact_details=contact_details
        self._contact_details=contact_details
        
    @property
    def name(self):
        return self._name
    
    @name.setter
    def name(self,value):
        if len(value)>1:
            self._name=value

            
        
    @property
    def age(self):
        return self._age
        
    @age.setter
    def age(self,value):
        if type(value)==int and value>=0:
            self._age=value
    @property
    def email(self):
        return self._contact_details['email']
    @email.setter
    def email(self,value):

        if type(value)==str:
            count=0
            for i in value:
                if i =='@':
                    count+=1
                    if count==1:
                        value=value.split('@')
                        if '.' not in value[1]:
                            self._contact_details['email']=self._contact_details['email']
                        if '!' in value[0]:
                            self._contact_details['email']=self._contact_details['email']
                        else:
                            self._contact_details['email']=value