from libdw import sm
import copy
class VacuumRobot(sm.SM):
    start_state = ([0,0],'up')
    displacement = {'up':(0,1), 'left':(-1,0), 'right':(1,0),'down':(0,-1)}
    def get_next_values(self, state, inp):
        displacement = {'up':[0,1], 'left':[-1,0], 'right':[1,0],'down':[0,-1]}
        if inp==False:
            get_displacement=displacement[state[1]]
            nextstate=state
            nextstate[0]=nextstate[0]+get_displacement #get new state by adding displacement value to current state
            output=nextstate
            return next_state, output
        else:
            current_direction=state[1]
            if current_direction=='up': #changes direction to next direction, before getting displacement value of next direction from dictionary. update based on this displacement value
                next_direction=='left'
                get_displacement=displacement[next_direction]
                nextstate=state
                nextstate[0]=nextstate[0]+get_displacement
                output=nextstate
            if current_direction=='left':
                next_direction=='down'
                get_displacement=displacement[next_direction]
                nextstate=state
                nextstate[0]=nextstate[0]+get_displacement
                output=nextstate
            if current_direction=='down':
                next_direction=='right'
                get_displacement=displacement[next_direction]
                nextstate=state
                nextstate[0]=nextstate[0]+get_displacement
                output=nextstate
            if current_direction=='right':
                next_direction=='up'
                get_displacement=displacement[next_direction]
                nextstate=state
                nextstate[0]=nextstate[0]+get_displacement
                output=nextstate
        
        return next_state, output

    def done(self, state):
        pass