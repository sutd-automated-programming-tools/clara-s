
def wordcount (s):

    s=(s.split('\n'))
    ans=[]
    length=len(s)
#    print(s)
    for l in range(length):
#        print(l)
        i=s[l]      
        i=i.strip(' ')
        i=i.split(' ')
#        print(i)
        if len(i)==1:
            if i[0]=='':
                ans.append(None)
            else:
                ans.append(1)
        else:
            i.sort()
            print(i)
            for k in i:
                k=k.strip(':')
                k=k.strip(';')
                k=k.strip(',')
                k=k.strip(', ')
                k=k.strip('.')
                k=k.strip('-')
                
            
                
#                k=k.split(':')
#                k=k.split(';')
#                k=k.split(',')
#                k=k.split(', ')
#                k=k.split('.')
#                k=k.split('-')


            ans.append(len(i))
            
            
        
    return ans