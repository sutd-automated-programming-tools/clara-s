#####################
#Starter code for Q3#
#####################

def equity(f):
    receive=0
    pay=0
    for v in f.values():
        receive = receive + v[0]
        pay= pay+v[1]
    net=receive-pay
    return (receive,pay,net)
        

