# FINAL EXAM: QUESTION 4


def wordcount (s):
    ls=[]
    line=''
    num=1
    for i in s: 
        print(i)
        if i !="\n" and i !=" ": 
            line+=i 
            print(line)
        if i == " ":
            ls.append(line) # append prev line
            num+=1 # no. of words increase
            line==''# resets line
            line+=i 
    
    return ls # ls is a list with strings of each line 
            

print(wordcount('Tom Dick Harry'))

def wordcount2(s): # count no. of words in a line 
    count=1
    for i in s: 
        if i == " " : 
            count+=1
        
    return count 
    
print(wordcount2('Tom Dick Harry'))
    

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 