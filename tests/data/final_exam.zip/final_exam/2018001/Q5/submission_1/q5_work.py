class Person:
    def __init__(self,name='Unknown',age=0,contact_details={'phone':"+65 0000 0000", 'email':'nobody@nowhere.com.sg'}): 
        self.name=name
        self.age=age
        self.contact_details=contact_details 
        
    def getnm(self): 
        return self._nm 
    
    def setnm(self, nm):
        if isinstance(nm,str) and len(nm)>1:
            self._nm = nm
        else:
            self._nm = self.name # if the value is ok, like pos, we will set 
    
    name = property(getnm,setnm)
    
    def getage(self): 
        return self._age 
    
    def setage(self, a):
        if isinstance(a,int) and a>=0:
            self._age = a
        else:
            self._age = self.age # if the value is ok, like pos, we will set 
    
    age = property(getage,setage)
    
    def getemail(self): 
        return self._email 
    
    def setemail(self, e):
        count=0
        if isinstance(e,str) and \
        for c in e: 
            if c.isalnum()==True or c=="@"or c== "." and Count(s)==1 and 
            
            
        
            
            self._age = a
    def Count(s):
        for c in s: 
            if c=="@": 
                count+=1
            return count 
   

    sbef=''
    saf=''
    for c in s: 
        if c!= "@":
            sbef+=c
        if c == "@": 
            break 
    return sbef 
    if sbef.c.isalnum()==True or c== "." or c=="_":
        return True 
    
    for c in s: 
        if c!= "@":
            saf+=''
        if c == "@": 
            saf+=""
    if "." in saf: 
        return True 
            
            
    

    

        
        
        
        
        
        
        
        else:
            self._email = self.email # if the value is ok, like pos, we will set 
    
    age = property(getemail,setemail)
    
    
    