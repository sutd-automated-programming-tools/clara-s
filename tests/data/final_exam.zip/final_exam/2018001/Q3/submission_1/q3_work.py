#####################
#Starter code for Q3#
#####################

def equity(f):
    
    keys = f.keys()
    values = f.values()
    l=list(keys) # l=list of keys in dict
    print(l)

    # v=list(values)
    # print(v)
    count1=0
    count2=0
    for i in l: #  i is the key 
        ls=f[i] # ls is the list for a key
        count1+=ls[0]
        count2+=ls[1]
    return (count1,count2,count1-count2)




