# FINAL EXAM: QUESTION 6


from libdw import sm
import copy
class VacuumRobot(sm.SM):
    start_state = None
    displacement = {'up':(0,1), 'left':(-1,0), 'right':(1,0),'down':(0,-1)}
    def __init__(self): 
        self.count=0
        self.x=0
        self.y=0
        
    def get_next_values(self,state,inp):
        if state=="x":
            if inp==False::
                self.x=self.x+1 # giving self.x a new value
                return "x",(self.x,self.y) # when u return a value, you do not assign any value to it. ,bec its just adding to it and there is no assignemnt 
            if inp==True: 
                return "y", (self.x, self.y)
        
        if state=="y":
            if inp==False::
                self.y=self.y+1 # giving self.x a new value
                return "y",(self.x,self.y) # when u return a value, you do not assign any value to it. ,bec its just adding to it and there is no assignemnt 
            if inp==True: 
                return "-x", (self.x, self.y)
        
            
        if state=="-x":
            if inp==False::
                self.x=self.x-1 # giving self.x a new value
                return "-x",(self.x,self.y) # when u return a value, you do not assign any value to it. ,bec its just adding to it and there is no assignemnt 
            if inp==True: 
                return "-y", (self.x, self.y)
        
        
        if state=="-y":
            f inp==False::
                self.y=self.y-1 # giving self.x a new value
                return "-y",(self.x,self.y) # when u return a value, you do not assign any value to it. ,bec its just adding to it and there is no assignemnt 
            if inp==True: 
                return "x", (self.x, self.y)
        
           
            

