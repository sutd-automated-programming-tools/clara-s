def numofat(e):
    n=0
    for l in e:
        if l=='@':
            n+=1
    return n
def check3(e):
    x=0
    ls=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','1','2','3','4','5','6','7','8','9','0','.','_','@']
    for l in e:
        if l in e:
            x=x+0
        else:
            x=x+1
    return x==0

def check4(e):
    n=0
    x=0
    while n<len(e):
        if e[n]=='@':
            break
        else:
            n+=1
    while n<len(e):
        if e[n]=='.':
            x+=1
            n+=1
        else:
            x+=0
            n+=1
    return x>=1
class Person:
    def __init__(self,name="Unknown",age=0,contact_details={'phone':'+65 000 000','email':'nobody@nowhere.com.sg'}):
        self._name=name
        self._age=age
        self.contact_details=contact_details
    def getName(self):
        return self._name

    def setName(self,newname):
        if type(newname)==str and len(newname)>=1:
            x=newname
        else:
            x=self.name
        self._name = x
    name = property(getName, setName)
    def getAge(self):
        return self._age

    def setAge(self,newAge):
        if type(newAge)==int and newAge>0:
            newAge=newAge
        else:
            newAge=self.age
        self._age = newAge

    age = property(getAge, setAge)
    
    def getemail(self):
        return self.contact_datails['email']

    def setemail(self,newemail):
        if type(newemail)==str and numofat(newemail)==True and check3(newemail)==True and check4(newemail)==True:
            newemail=newemail
        else:
            newemail=self._contact_details['email']
        self.contact_details = newemail

    email = property(getemail, setemail)