from libdw import sm

# Implement the SMExtra class below:

class SMExtra(sm.SM):
    
    def get input_for_output(self,output_list):
        ls=[]
        for i in output_list:
            ls.append(self.step(i))
        return ls
# The following state machine classes are provided for testing
# DO NOT modify the code, otherwise the tests may not work
    
class TorchLight(SMExtra):
    start_state = 0
    
    valid_inputs = ['push']
    
    def get_next_values(self, state, inp):        
        if state == 0:
            next_state = 1
            output = 'on'
        elif state == 1:
            next_state = 0
            output = 'off'
            
        return next_state, output
    
class UpAndDown(SMExtra):
    start_state = 0
    
    valid_inputs = ['up', 'down']
    
    def get_next_values(self, state, inp):
        assert(inp == 'up' or inp == 'down')
        assert(0 <= state)
        
        if inp == 'up':
            next_state = state + 1
            output = next_state
        elif inp == 'down':
            next_state = state - 1
            output = next_state
            
        return next_state, output
    
class CokeMachine(SMExtra):
    start_state = 0
    
    valid_inputs = [5, 10, 20, 50, 100]

    def get_next_values(self,state, inp):
        if state == 0 and inp == 100:
            next_state = 0
            output=(0,'coke',0)
        elif state == 0 and inp == 50:
            next_state = 1
            output=(50,'--',0)
        elif state == 1 and inp ==100:
            next_state = 0
            output = (0, 'coke', 50)
        elif state == 1 and inp==50:
            next_state = 0
            output = (0,'coke',0)
        else:
            next_state = state
            if state == 1:
                balance = 50
            else:
                balance = 0
            output = (balance,'--',inp)
        return next_state,output