# FINAL EXAM: QUESTION 4


def wordcount(string1):
    finalls=[]
    finalSure=[]
    lsSplitnl=string1.split('\n')
    for line in lsSplitnl:
        if line== ' ':
            finalls.append(None)
        else:
            if type(line)== list:
                try:
                    test= finalls.append(line.split(' '))
                except:
                    pass
                if test[0][0].isUpper() and test[1][0].isUpper():
                    finals.append(line)
                else: 
                    finalls.append(line.split(' '))
            else:
                
                    finalls.append(line.split(' '))
    
    print(finalls)
    for thing in finalls:
        if thing == None:
            finalSure.append(None)
        elif type(thing)== str:
            
            finalSure.append(1)
        else:
            
            finalSure.append(sum(1 for i in thing if not i== ''))
    return finalSure

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 