
class Person():
    m_list=[]
    def __init__(self, name='Unknown', age=0, contact_details={'phone':'+65 0000 0000','email':'nobody@nowhere.com.sg'}):
        self._name=name
        self._age=age
        self.contact_details=contact_details
        self._mother = None
    
    
    def get_name(self):
        return self._name
    
    def set_name(self,nn):
        if type(nn)==str and len(nn)>0 and not nn.isdigit():
            self._name=nn
        
    def get_age(self):
        return self._age
    def set_age(self,na):
        if type(na)==int:
            if na>=0:
                self._age=na
    def getemail(self):
        return self.contact_details['email']
    def setemail(self,str1):
        if type(str1)==str:
            acount=0
            state=False
            dotcount=False
            for letter in str1:
                if letter=='@':
                    acount+=1
                    state=True
                if state and letter=='.':
                    dotcount=True
                if letter.isupper() or letter.islower() or letter =='_' or letter =='.' or letter =='@':
                    pass
                else:
                    return 0
            if acount==1 and dotcount==True:
                self.contact_details['email']=str1
    name=property(get_name,set_name)
    age=property(get_age,set_age)
    email=property(getemail,setemail)
    
    def getM(self):
        return self._mother
    
    def setM(self,m):
        if type(m)== Person:
            self._mother = m
            
    mother=property(getM,setM)