# FINAL EXAM: QUESTION 6

from libdw import sm
import copy
class VacuumRobot(sm.SM):
    start_state = [[0,0],'up']

    def get_next_values(self, state, inp):
        if inp == False:
            if state[1]=='up':
                nstate=[[state[0][0],state[0][1]+1],'up']

            elif state[1]=='down':
                nstate=[[state[0][0],state[0][1]-1],'down']

            elif state[1]=='left':
                nstate=[[state[0][0]-1,state[0][1]],'left']

            elif state[1] == 'right':
                nstate = [[state[0][0] +1, state[0][1]], 'right']
        elif inp==True:
            if state[1] == 'up':
                nstate = [[state[0][0]-1, state[0][1]], 'left']

            elif state[1] == 'down':
                nstate = [[state[0][0]+1, state[0][1]], 'right']

            elif state[1] == 'left':
                nstate = [[state[0][0], state[0][1]-1], 'down']

            elif state[1] == 'right':
                    nstate = [[state[0][0], state[0][1]+1], 'up']

            return (state[0][0],state[0][1]),nstate
    def done(self, state):
        pass
    
v = VacuumRobot()
print('Test 1:')
inp = [False, True, False, False, True, True, False, False
ans = v.transduce(inp)
print(ans)

print('Test 2:')
v = VacuumRobot()
inp = [False, False, True, False, False, True, False, True, False, False, False, False]
ans = v.transduce(inp)
print(ans)

print('Test 3:')
v = VacuumRobot()
inp = [False, False, False, True, False, False, True, False, False, True, False, False, False,
False,False, False]
ans = v.transduce(inp)
print(ans)

print('Test 4:')
v = VacuumRobot()
v.start()
inp = [False, True, False, False, True, True, False, False]
state = v.state
for i in inp:
    ns, o = v.get_next_values(state, i)
    state = ns
status = v.state == v.start_state
print('State:', v.state)
print('Not Modified:',status)


