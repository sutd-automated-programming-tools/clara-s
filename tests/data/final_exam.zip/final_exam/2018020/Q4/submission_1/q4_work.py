# FINAL EXAM: QUESTION 4


def wordcount(s):
    sl = s + " "
    words = []
    w = 0
    w1 = 0
    
    if "\n" not in sl:
        for e in sl:
            if e == " ":
                w += 1
        words.append(w)
        
    elif "\n" in sl:
        for e in sl:
            if e == " ":
                w += 1
            
            elif e == "\n":
                words.append(w)
                
        
            
        print(e)
    
    return words

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 