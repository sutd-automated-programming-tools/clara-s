class Person():
    def __init__(self, name="Unknown", age=0, contact_details={"phone":"+65 0000 0000", "email":"nobody@nowhere.com.sg"}):
        self.name = name
        self.age = age
        self.contact_details = contact_details
        
    def get_name(self):
        return self._name
    
    def set_name(self, value):
        if len(value) > 1 and isinstance(value, str) == True:
            self._name = value
        else:
            self._name = self.name
        return self._name
    
    def get_age(self):
        return self._age
    
    def set_age(self, value):
        if value >= 0 and isinstance(value, int) == True:
            self._age = value
        else:
            self._age = self.age
        return self._age
            
    name = property(get_name, set_name)
    age = property(get_age, set_age)
    
    def get_email(self):
        return self.contact_details
    
    def set_email(self, value):
        if isinstance(value, str):
            counter = 0
            for e in value:
                if e == "@":
                    counter += 1
            if counter == 1:
                
        
    email = property(get_email, set_email)