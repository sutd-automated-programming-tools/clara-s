# FINAL EXAM: QUESTION 6

from libdw import sm
import copy
class VacuumRobot(sm.SM):
    start_state = 0
    x = 
    y = 0
    displacement = {'up':(0,1), 'left':(-1,0), 'right':(1,0),'down':(0,-1)}
    def get_next_values(self, state, inp):
        if state == 0 and inp == False:
            next_state = 0
            displacement = [0, 1]
            x += displacement[0]
            y += displacement[1]
            last_movement = "up"
            boundary = (x, y)
            
        elif state == 0 and inp == True:
            next_state = 1
        
        return next_state, output

    def done(self, state):
        pass
    
v = VacuumRobot()
print('Test 1:')
inp = [False, True, False, False, True, True, False, False]
ans = v.transduce(inp)
print(ans)

print('Test 2:')
v = VacuumRobot()
inp = [False, False, True, False, False, True, False, True, False, False, False, False]
ans = v.transduce(inp)
print(ans)

print('Test 3:')
v = VacuumRobot()
inp = [False, False, False, True, False, False, True, False, False, True, False, False, False,
False,False, False]
ans = v.transduce(inp)
print(ans)

print('Test 4:')
v = VacuumRobot()
v.start()
inp = [False, True, False, False, True, True, False, False]
state = v.state
for i in inp:
    ns, o = v.get_next_values(state, i)
    state = ns
status = v.state == v.start_state
print('State:', v.state)
print('Not Modified:',status)


