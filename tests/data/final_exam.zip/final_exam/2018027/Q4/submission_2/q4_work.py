# FINAL EXAM: QUESTION 4

def ne(s):
    new = []
    for i in s.split():
        if i not in new:
            new.append(i)
    print(new)
    return len(new)
        

def wordcount (s):
    li = [i for i in s.split('\n')]
    ln = []
    for i in li:
        n = i.strip(':').strip(';').strip(',').strip('.').strip('-')
        ln.append(n)
    print(ln)
    num = [ne(j) for j in ln]
    print(num)
    for k in range(len(num)):
        if num[k] == 0:
            num[k] = None
    
    return num

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 