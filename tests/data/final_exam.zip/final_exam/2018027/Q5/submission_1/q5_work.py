class Person:
    def __init__(self, name = 'Unknown', age = 0, c_d = {'phone':'+65 0000 0000', 'email':'nobody@nowhere.com.sg'}):
        self._name = name
        self._age = age
        self.contact_details = c_d
        self._email = self.contact_details['email']
        
    def getname(self):
        return self._name
    
    def setname(self, name):
        if isinstance(name, str) and len(name)>0:
            self._name = name
        
    def getage(self):
        return self._age
    
    def setage(self, age):
        if isinstance(age, int):
            self._age = age
            
    def getc_d(self):
        return self.contact_details.email
    
    def setc_d(self, c_d):
        if type(c_d) == str and c_d.count('@') == 1:
            li = c_d.split('@')
            con1 = True
            con2 = True
            for i in li[0]:
                con1 =  (i.isalnum() or i == '.' or i == '_') and con1                    
            for j in li[1]:
                con2 = (j.isalnum() or j == '.' or j == '_') and con2
            con3 = li[1].count('.') > 0
            if con1 and con2 and con3:
                self.contact_details['email'] = c_d
                
    name = property(getname, setname)
    age = property(getage, setage)
    email = property(getc_d, setc_d)