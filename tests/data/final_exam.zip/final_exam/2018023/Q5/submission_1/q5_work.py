class Person():
    def __init__(self,name='Unknown',age=0,contact_details = {'phone' : '+65 0000 0000', 'email' : 'nobody@nowhere.com.sg'}, mother = None):
        self.name = name
        self.age = age
        self.contact_details = contact_details
        self.mother = mother
    def get_name(self):
        return self._name
    def set_name(self,name):
        if isinstance(self.name,str) == True and len(name) >=1:
            self._name = self.name
        else:
            self.name =  self.name
    def get_age(self):
        return self._age
    def set_age(self,age):
        if type(self.age) == int and self.age >= 0:
            self._age = self.age
        else:
            self.age = self.age
    age = property(get_age, set_age)
    name = property(get_name,set_name)
    
    def get_email(self):
        return self.contact_details['email']
    def setemail(self,contact_details):
        if type(self.contact_details['email'] == str:
               check that the count of @ is 1:
                     check that the string contains '.' or '_' and that it is alphanumeric
                     remove part of the string up until @ symbol and check that there is at least one '.'
    def get_mother(self):
        return self.mother
    def set_mother(self,mother):
        if self.mother != self.mother:
                if self.mother == None or self.mother is referencing object from class person
                  
                