# FINAL EXAM: QUESTION 4


def wordcount (s):
    if '\n' in s:
        s1 = s.split('\n')
    else:
        s1 = s
    punc = [':',';','.',',','-']
    for i in s1:
        if i in punc:
            s1.remove(i)
    lst = []
    for i in s1:
        wordcount = 0
        s2 = i.split( )
        if len(s1) == 1:
            for j in range(len(s2)):
                check that each s2[j] until the length is not the same and make wordcount equals to the len
                
            lst.append(wordcount)
        if i == '':
                lst.append(None)
        if len(s2) > 1:
            for j in range(len(s2)):
                if s2[j] == s2[j+1]:
                    wordcount += 1
                    lst.append(wordcount)
                
                elif s2[j] != s2[j+1]:
                    wordcount+=2
                    lst.append(wordcount)
        else:
            pass
    
            
            
        
        
    return lst

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 