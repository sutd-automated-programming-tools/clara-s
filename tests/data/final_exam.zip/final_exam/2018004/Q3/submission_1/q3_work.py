#Q3 raw 
def equity(f): 
    rec = 0 
    pay = 0 
    for key in f.keys():
        rec += f[key][0]
        pay += f[key][1]
    net = rec - pay
    return tuple([rec,pay,net])
    # rec = 0 
    # pay = 0 
    # for key in f.keys(): 
    #     rec += f[key][0] 
    #     pay += f[key][1]
    # net = rec - pay
    # return tuple([rec,pay,net])

############
#Test cases#
############
f1={'A': [100, 0], 'B': [100, 0], 'C': [100, 0]}
f2={'M': [30, 20], 'N': [50, 70], 'O': [60, 80]}
f3={'J': [0, 30], 'K': [0, 20], 'L': [0, 40]}

print(equity(f1))
print(equity(f2))
print(equity(f3))

