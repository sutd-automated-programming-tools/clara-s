class Person:
    def __init__(self, name='Unknown', age=0, contact_details={'phone': '+65 0000 0000', 'email':'nobody@nowhere.com.sg'}): 
        self.name = name
        self.age = age 
        self.contact_details = contact_details
        
    def get_name(self): 
        return self._name
    
    def set_name(self, value):
        if len(value)>= 1: 
            if isinstance(value,str): 
                self._name = value
                return self._name
        self._name = self.name
        return self._name
    
    def get_age(self): 
        return self._age
    
    def set_age(self, age1): 
        self._age = age1 if isinstance(age1, int) and age1 >= 0 else self.age
        return self._age
        
    name = property(get_name, set_name)
    age = property(get_age, set_age) 
    
    def get_email(self): 
        return self._email
    
    def set_email(self, value): 
        countat = 0 
        for char, num in enumerate(value): 
            if char == '@':
                countat += 1 
                c = num
        bef = value[:c]
        aft = value[c+1:]
        countdot = 0 
        for char in aft: 
            if char == '.': 
                countdot += 1

        self._email = value if isinstance(value, str) and countat == 1 and self.checkbef(bef) and countdot >= 1 else self.contact_details['email']
        return self._email
        
#    def checkbef(self, value): 
#        for char in value: 
#            if char.isalpha() or char.isdigit() or char == '.' or char == '_': 
#                pass
#            else: 
#                return False
#        return True
#    
#    contact_details['email'] = property(get_email, set_email) 
            
p = Person() 
print(p.name, p.age) 
print(p.contact_details)