#Q4 raw

def wordcount(s):
    string = s.split('\n') 
    ls = []
    newls = []
    for i in range(len(string)): 
        string[i] = string[i].split()
    for item in string: 
        newls = []
        for thing in item: 
            if thing not in newls: 
                newls.append(thing) 
        if len(newls) > 0: 
            ls.append(len(newls))
        else: 
            ls.append(None)
    return ls

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n."))