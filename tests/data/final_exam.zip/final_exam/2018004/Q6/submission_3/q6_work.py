from libdw import sm 

class VacuumRobot(sm.SM): 
    start_state = 'up'
    x, y = 0, 0
    xbound, ybound = -100000, 100000 #add a boundary restriction
    #decrease bound after every turn 
    def get_next_values(self, state, inp):
        if state == 'up': 
            if inp == False <= self.ybound : 
                self.y += 1 
                return 'up', (self.x, self.y) 
            elif inp == True or inp >= ybound: 
                self.x -= 1
                self.ybound = self.y-1
                return 'left', (self.x, self.y)
            
        elif state == 'left': 
            if inp == False or self.x > self.xbound: 
                self.x -= 1
                return 'left', (self.x, self.y) 
            elif inp == True or self.x <= self.xbound : 
                self.y -= 1
                self.xbound = self.x -1
                return 'down', (self.x, self.y) 
            
        elif state == 'down': 
            if inp == False or self.y > self.ybound: 
                self.y -= 1
                return 'down', (self.x, self.y) 
            elif inp == True or self.y <= self.ybound: 
                self.x += 1
                self.ybound = self.y-1
                return 'right', (self.x, self.y) 
            
        elif state == 'right': 
            if inp == False or self.x < self.xbound: 
                self.x += 1 
                return'right', (self.x, self.y) 
            elif inp == True or self.x >= self.xbound : 
                self.y += 1
                self.xbound = self.x-1 
                return 'up', (self.x, self.y) 
    
v = VacuumRobot()
print('Test 1:')
inp = [False, True, False, False, True, True, False, False]
ans = v.transduce(inp)
print(ans)

print('Test 2:')
v = VacuumRobot()
inp = [False, False, True, False, False, True, False, True, False, False, False, False]
ans = v.transduce(inp)
print(ans)

print('Test 3:')
v = VacuumRobot()
inp = [False, False, False, True, False, False, True, False, False, True, False, False, False,
False,False, False]
ans = v.transduce(inp)
print(ans)

print('Test 4:')
v = VacuumRobot()
v.start()
inp = [False, True, False, False, True, True, False, False]
state = v.state
for i in inp:
    ns, o = v.get_next_values(state, i)
    state = ns
status = v.state == v.start_state
print('State:', v.state)
print('Not Modified:',status)


