'''class Person:'''

class Person:
    def __init__(self, name='Unknown', age=0, contact_details={}):
        self.name =str(name)
        self.age = int(age)
        self.contact_details=details