#####################
#Starter code for Q3#
#####################
'''
def equity(f):
	pass'''

def equity(f):
	
	x=[]
	r=x.append(f.values)
	a=[r[0][0]+r[0][1]+r[0][2]]
	y=[]
	p=y.append(f.values)
	b=[[p[0][0]+p[0][1]+p[0][2]]]
	totr= sum(a)
	totp= sum(b)
	net = totr - totp
	return print(totr, totp, net)
# extract values from dict
#separate receivable and payable values into 2 lists
# add all values in r together giving total receivable
	# add all values in p together giving total payable
	# to find net equity subtract total receivable with total payable 
	# return print(totr,totp,net)
############
#Test cases#
############
f1={'A': [100, 0], 'B': [100, 0], 'C': [100, 0]}
f2={'M': [30, 20], 'N': [50, 70], 'O': [60, 80]}
f3={'J': [0, 30], 'K': [0, 20], 'L': [0, 40]}

print(equity(f1))
print(equity(f2))
print(equity(f3))

