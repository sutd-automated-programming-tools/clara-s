# FINAL EXAM: QUESTION 4


def wordcount (s):
    pass
# for number of lines 
# check for number of lines using s.count('\n')
# this value+1 is number of lines 
# separate the lines into 2 different lists using 
#for each line, delete punctuations from the list 
s.strip(':', ';', ',', '.', '-') 
#count total number of occurrences of white spacing in string 
s.count('')
# this is number of separate words
# append to list each word
# traverse list for non unique non disticnt words 
# delete words from list using pop
# count number of words in new list using counter when appending to another new list
# check for no words in a line 
# return None when list is empty 
# append teh 3 values into a list and return for answer

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 