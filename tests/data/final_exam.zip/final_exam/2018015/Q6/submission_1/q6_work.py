# FINAL EXAM: QUESTION 6

from libdw import sm
import copy
class VacuumRobot(sm.SM):
    start_state = ['findboundary', (0,0), None, 1]
    displacement = {'up':[0,1], 'left':[-1,0], 'right':(1,0),'down':(0,-1)}
    def get_next_values(self, state, inp):
        if state == ['findboundary', (0,0), None, 1]:
            pos = (0,1)
            fstate = 'findboundary'
            last_movement = 'up'
            boundary = 1
            self.next_state = fstate, pos, last_movement, boundary
            self.output = pos
        
#        elif state[0] == 'findboundary' and state[3] == 1:
#            self.next_state = state            
##            pos = (state[1][0] + self.displacement['up'][0] , state[1][1] + self.displacement['up'][1])
##            if inp == True:
##                state[3] = 2
#            self.next_state[2] = 'up'
#            self.output = pos
            
        return self.next_state, self.output

    def done(self, st
    
v = VacuumRobot()
print('Test 1:')
inp = [False, True, False, False, True, True, False, False]
ans = v.transduce(inp)
print(ans)

print('Test 2:')
v = VacuumRobot()
inp = [False, False, True, False, False, True, False, True, False, False, False, False]
ans = v.transduce(inp)
print(ans)

print('Test 3:')
v = VacuumRobot()
inp = [False, False, False, True, False, False, True, False, False, True, False, False, False,
False,False, False]
ans = v.transduce(inp)
print(ans)

print('Test 4:')
v = VacuumRobot()
v.start()
inp = [False, True, False, False, True, True, False, False]
state = v.state
for i in inp:
    ns, o = v.get_next_values(state, i)
    state = ns
status = v.state == v.start_state
print('State:', v.state)
print('Not Modified:',status)


