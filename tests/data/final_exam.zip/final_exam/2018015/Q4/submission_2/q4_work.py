# FINAL EXAM: QUESTION 4


def wordcount (s):
    newlist = s.split('\n')
#    print (newlist)
    ret_val = []
    for line in newlist:
        newnewlist = line.split(' ')
#        for i in range(len(newnewlist)):
#            newnewlist.remove('" "')
#        print (newnewlist)
        
        for i,j in enumerate(newnewlist):
            for k in range(len(newnewlist)):
                if i != k and newnewlist[i] == newnewlist[k]:
                    newnewlist.remove(j)
        ret_val.append(len(newnewlist))
        
    return ret_val

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 