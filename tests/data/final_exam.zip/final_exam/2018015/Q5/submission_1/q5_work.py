class Person:
    def __init__ (self, name = 'Unknown', age = 0, contact = {'phone':'+65 0000 0000', 'email':'nobody@nowhere.com.sg'}):
        self._name = name
        self._age = age
        self.contact_details = contact
        self._mother = None
    
    def setname(self,value):
        if type(value) == str:
            if len(value) >= 1:
                self._name = value
                
    def getname(self):
        return self._name
    
    def setage(self,value):
        if type(value) == int:
            if value >= 0:
                self._age = value
                
    def getage(self):
        return self._age    
    
    def setemail(self,value):
        count = 0
        for char in value:
            if char == '@':
                count +=1
        if count == 0:
            return None
        mylist = value.split('@')
#        print (mylist)
#        print (mylist[0])
#        print (mylist[1])
        leftcount = 0
        for leftchar in mylist[0]:
            if leftchar.isalpha() == True or leftchar == '.' or leftchar == '_':
                leftcount += 1
        if leftcount == len(mylist[0]):
            leftcount = 'ok'
        rightcount = 0
        for rightchar in mylist[1]:
            if rightchar == '.':
                rightcount += 1
        if type(value) == str:
            if count == 1:
                if leftcount == 'ok':
                    if rightcount >= 1:
                        self.contact_details['email'] = value               
        
    def getemail(self):
        return self.contact_details['email']
    
    def setmom(self, m):
        if m == None or type(m) == Person:
            if m != self.name:
                self._mother = m
        
    def getmom(self):
        return self._mother
    
    
    name = property(getname,setname)
    age = property(getage,setage)
    email = property(getemail,setemail)
    mother = property(getmom,setmom)