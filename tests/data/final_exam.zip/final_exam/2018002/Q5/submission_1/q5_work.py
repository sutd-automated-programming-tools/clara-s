class Person:
    pass