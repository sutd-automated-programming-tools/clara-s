# FINAL EXAM: QUESTION 6

from libdw import sm
import copy
class VacuumRobot(sm.SM):
    start_state = None
    displacement = {'up':(0,1), 'left':(-1,0), 'right':(1,0),'down':(0,-1)}
    lst = []
    def get_next_values(self, state, inp):
        if state == None:
            x = 0
            y = 0
            if inp:
                next_state = 'up'
                y += 1
                output = (x,y)
                lst.append(output)
            else:
                next_state = 'left'
                x -= 1
                output = (x, y)
                lst.append(output)
        elif state == 'up':
            y += 1
            if (x, y) in lst:
                inp = True
            y -= 1
            if inp:
                state = 'left'
                x -= 1
                output = (x, y)
                lst.append(output)
            else:
                state == 'up'
                y += 1
                output = (x, y)
                lst.append(output)
        elif state == 'left':
            x -= 1
            if (x, y) in lst:
                inp = True
            x += 1
            if inp:
                state = 'down'
                y -= 1
                output = (x, y)
                lst.append(output)
            else:
                state = 'left'
                x -= 1
                output = (x, y)
                lst.append(output)
        elif state == 'down':
            y -= 1
            if (x, y) in lst:
                inp = True
            y += 1
            if inp:
                state == 'right'
                x += 1
                output = (x, y)
                lst.append(output)
            else:
                state == 'down'
                y -= 1
                output = (x, y)
                lst.append(output)
                
        elif state == 'right':
            x += 1
            if (x, y) in lst:
                inp = True
            x -= 1
            if inp:
                state == 'up'
                y += 1
                output = (x, y)
                lst.append(output)
            else:
                state == 'right'
                x += 1
                output = (x, y)
                lst.append(output)
        
        return next_state, output
    
v = VacuumRobot()
print('Test 1:')
inp = [False, True, False, False, True, True, False, False]
ans = v.transduce(inp)
print(ans)

print('Test 2:')
v = VacuumRobot()
inp = [False, False, True, False, False, True, False, True, False, False, False, False]
ans = v.transduce(inp)
print(ans)

print('Test 3:')
v = VacuumRobot()
inp = [False, False, False, True, False, False, True, False, False, True, False, False, False,
False,False, False]
ans = v.transduce(inp)
print(ans)

print('Test 4:')
v = VacuumRobot()
v.start()
inp = [False, True, False, False, True, True, False, False]
state = v.state
for i in inp:
    ns, o = v.get_next_values(state, i)
    state = ns
status = v.state == v.start_state
print('State:', v.state)
print('Not Modified:',status)


