class Person:
    di = {'phone': '+65 0000 0000', 'email': 'nobody@nowhere.com.sg'}
    def __init__(self, name='Unknown', age=0, contact=di):
        self.name = name
        self.age = age
        self.contact_details = contact
        
    def get_name(self):
        return self._name
    
    def set_name(self, inp):
        if isinstance(inp, str) and len(inp) > 0:
            self._name = inp
        
    name = property(get_name, set_name)
    
    def get_age(self):
        return self._age
    
    def set_age(self, inp):
        if isinstance(inp, int) and inp >= 0:
            self._age = inp
        
    age = property(get_age, set_age)
    
        def get_email(self):
        return self.contact_details['email']
    
    def set_email(self, inp):
        if isinstance(inp, str) and '@' in inp:
            lst = inp.split('@')
            if len(lst) == 2:
                count = 0
                for i in lst[0]:
                    if i.isalpha() or i.isdigit() or i == '.' or i == '_':
                        valid = True
                    else:
                        valid = False
                        break
            if valid:
                for i in lst[1]:
                    if i.isalpha() or i.isdigit() or i == '.' or i == '_':
                        if i == '.':
                            count += 1
                if count >= 1:
                    valid = True
                else:
                    valid = False
            else:
                valid = False
        else:
            valid = False
        if valid:
            self.contact_details['email'] = inp
                    
    email = property(get_email, set_email)
    
    