# FINAL EXAM: QUESTION 4


def wordcount(s):
    lst1 = s.split('\n')
    outlst = []
    lst3 = []
    repeat = 0
    numwords = 0
    a = ''
    for i in lst1:
        lst2 = i.split(' ')
        for v in lst2:
            for k in v:
                if k.isalpha():
                    a += k
            lst3.append(a)
            a = ''
        while '' in lst3:
            lst3.remove('')
        for j in lst3:
            lst_len = len(lst3)
            if lst_len > 1:
                for i in range(lst_len - 1):
                    if lst3[i] == lst3[i+1]:
                        repeat += 1
        if repeat > 0:
            numwords = len(lst3) - 1
            repeat = 0
            lst3 = []
        elif len(lst3) == 0:
            numwords = None
        else:
            numwords = len(lst3)
            lst3 = []
        outlst.append(numwords)
    return outlst

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 