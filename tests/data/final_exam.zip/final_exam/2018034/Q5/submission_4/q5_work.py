import copy

class Person:
    def __init__(self, name= "Unknown", age=0, contact_details={'phone':'+65 0000 0000', 'email': 'nobody@nowhere.com.sg'}):
        self.name = name
        self.age = age
        self.contact_details = contact_details
        self.email = contact_details['email']
        
    def getName(self):
        return self._name
    
    def setName(self, new_name):    
        c = isinstance(new_name,str)
        if c is True:
            self._name = new_name
        else:
            self._name = "Unknown"
        
    def getAge(self):
        return self._age
    
    def setAge(self, new_age):
        if isinstance(new_age, int):
            self._age = new_age
        else:
            return None
            
    def getEmail(self):
        return self.contact_details['email']
    def setEmail(self,inp):
        new = copy.deepcopy(inp)
        c = 0
        if new is str:
            new.split()
            if '@' in new:
                c +=1
                if '@' == 1:
                    pass
                else:
                    self.contact_details['email'] = 'nobody@nowhere.com.sg'