# FINAL EXAM: QUESTION 4
from libdw import sm

def wordcount (s):
    out = []
    c = 0
    s.replace(':', '')
    s.replace(';', '')
    s.replace(',', '')
    s.replace('.', '')
    s.replace('-', '')
    s.split(' ')
    for i in s:
        if "/n" in s[i]:
            out.append(c)
            c = 0
        if s[i].isalpha():
            out.append(None)
        for n in range(len(s)):
            if s[i] == s[n]:
                c += 1
            else:
                c += 0
            out.append(c)
    return out
        
         
        
            
    

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 