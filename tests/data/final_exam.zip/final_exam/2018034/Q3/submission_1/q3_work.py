#####################
#Starter code for Q3#
#####################

def equity(f):
    acc_pay = 0
    acc_rec = 0
    for index in f:
        c = f[index]
        acc_pay += c[1]
        acc_rec += c[0]
    net_eq = acc_rec - acc_pay
    return (acc_rec, acc_pay, net_eq)

############
#Test cases#
############
f1={'A': [100, 0], 'B': [100, 0], 'C': [100, 0]}
f2={'M': [30, 20], 'N': [50, 70], 'O': [60, 80]}
f3={'J': [0, 30], 'K': [0, 20], 'L': [0, 40]}

print(equity(f1))
print(equity(f2))
print(equity(f3))

