class Person:
    def __init__(self,name='Unknown',age=0,contact_details={'phone':'+65 0000 0000', 'email':'nobody@nowhere.com.sg'}):
        self.name = name
        self.age = age
        self.contact_details = contact_details
              
        
    def getName(self):
        return self._name
    
    def setName(self,inp):
        if isinstance(inp,str) and inp !='':
            self._name = inp
        
    name = property(getName,setName)
    
    def getAge(self):
        return self._age
    
    def setAge(self,inp):
        if isinstance(inp,int) and inp>=0:
            self._age = inp
            
    age = property(getAge,setAge)
    
    
    def getEmail(self):
        self._email = self.contact_details['email']
        return self._email
    
    def setEmail(self,inp):
        self._email = self.contact_details['email']
        valid = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','.','_']
        if isinstance(inp,str):
            for i in inp:
                count = 0
                if i == '@':
                    count = count + 1
                    if count == 1:
                        wrong = 0
                        for j in inp:
                            if j in valid:
                                wrong = wrong + 1
                                if wrong == len(inp):
                                    for k in range(len(inp)):
                                        if inp[k] == '@':
                                            numm = 0
                                            for p in inp[k:]:
                                                if p == '.':
                                                    numm = numm + 1
                                                    if numm >=1:
                                                        self._email = inp
                          
    email = property(getEmail,setEmail)