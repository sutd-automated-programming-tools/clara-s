# FINAL EXAM: QUESTION 4


def wordcount (s):
    split_ls = s.split('\n')
    len_ls = []
    ans_ls = []
    for word in split_ls:
        s_ls = word.split(' ')
        len_ls.append(s_ls)
        for i in len_ls:
            for j in i:
                ans = j.strip()
                if ans not in ans_ls:
                    ans_ls.append(ans)
                    k_ls = []
                    for k in ans_ls:
                        kk = k.strip('.')
                        kk1 = kk.strip(',')
                        k_ls.append(kk1)

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 