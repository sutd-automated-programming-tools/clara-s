class Person:
    def __init__(self, name= 'Unknown', age = 0, contact_details = {'phone': '+65 0000 0000', 'email':'nobody@nowhere.com.sg'}, mother=None):
        self.name = str(name)
        self.age = int(age)
        self.contact_details = contact_details
        self.mother = mother
    def getName(self):
        return self._name
    
    def setName(self, name):
        self._name = name
    
    name= property(getName,setName)
    
    def getAge(self):
        return self._age
    
    def setAge(self, age):
        self._age = age
    
    age= property(getAge,setAge)
    
    def getemail(self,email):
        return self._contact_details[email]
    
    def setemail(self, email):
        element = email.split("@")
        if type(email) == str and "@" in email and "." in element[0] == True or "." in element[1] == True or "_" in element[0] == True or "_" in element[1] == True or element[0].alpha() == True or element[0].isalpha() == True or element[0].isalnum == True or element[1].isalnum == True:
            self._contact_details[email] = email
    email= property(getemail,setemail)
    def getMother(self):
        return self._mother
    
    def setMother(self, mother):
        self._mother = mother
    mother= property(getMother,setMother)