class Person:
    def __init__(self,name='Unknown',age=0,contact_details={'phone':'+65 0000 0000','email':'nobody@nowehere.com.sg'}):
        self._name = name
        self._age = age
        self.contact_details = contact_details
        self._email = contact_details['email']
    
    def get_name(self):
        return self._name
    def set_name(self,inp):
        if type(inp) == str and len(inp) > 1:
            self._name = inp
    name  = property(get_name,set_name)
    
    def get_age(self):
        return self._age
    def set_age(self,inp):
        if type(inp) == int and inp%1 == 0:
            self._age = inp
    age = property(get_age,set_age)
    
    def get_email(self):
        return self._email
    def set_email(self,inp):
        if type(inp) == str:
            x = 0
            for i in range(len(inp)):
                if inp[i] == '@':
                    x += 1
            if x == 1:
                index = inp.find('@')
                before = inp[0:index]
                before  = before.strip('.')
                before = before.strip('_')
                after = inp[index+1:-1]
                after = after.strip('.')
                after = after.strip('_')
                y = 0
                print(before)
                for k in range(len(after)):
                    if after[k].isalpha == 'False':
                        return self._email
                    if after[k] == '.':
                            y += 1
                if y < 1:
                    return self._email
                else:
                    for j in range(len(before)):
                        print(before[j])
                        if before[j].isalpha == 'False':
                            print(before[j])
                            return self._email
            else:
                return self._email
    email = property(get_email,set_email)
