# FINAL EXAM: QUESTION 4


def wordcount (s):
    output = []
    if '\n' not in s:
        s = s.split()
        print(s)
        for i in range(len(s)):
            s[i] = s[i].strip(':')
            s[i] = s[i].strip(':')
            s[i] = s[i].strip(',')
            s[i] = s[i].strip('.')
            s[i] = s[i].strip('-')
        for j in range(len(s)):
            if s[j] not in output:
                output.append(s[j])
        return len(output)


print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 