# FINAL EXAM: QUESTION 6
from libdw import sm
import copy
class VacuumRobot(sm.SM):
    start_state = [[(0,0)], 0, 0, 'up']


    def get_next_values(self, state, inp):
        nextstate = copy.deepcopy(state)
        if inp == False:

            if state[3] == 'up':
                if (nextstate[1], nextstate[2]+1) not in nextstate[0]:
                    nextstate[2] += 1
                else:
                    nextstate[1] -= 1
                    nextstate[3] = 'left'

            if state[3] == 'left':
                if (nextstate[1] -1, nextstate[2]) not in nextstate[0]:
                    nextstate[1] -= 1
                else:
                    nextstate[2] -= 1
                    nextstate[3] = 'down'

            if state[3] == 'down':
                if (nextstate[1], nextstate[2] - 1) not in nextstate[0]:
                    nextstate[2] -= 1
                else:
                    nextstate[1] += 1
                    nextstate[3] = 'right'

            if state[3] == 'right':
                if (nextstate[1] + 1, nextstate[2]) not in nextstate[0]:
                    nextstate[1] += 1
                else:
                    nextstate[2] += 1
                    nextstate[3] = 'up'
        if inp == True:
            if state[3] == 'up':
                nextstate[1] -= 1
                nextstate[3] = 'left'
            if state[3] == 'left':
                nextstate[2] -= 1
                nextstate[3] = 'down'
            if state[3] == 'down':
                nextstate[1] += 1
                nextstate[3] = 'right'
            if state[3] == 'right':
                nextstate[2] += 1
                nextstate[3] = 'up'
        nextstate[0].append((nextstate[1],nextstate[2]))
        return nextstate, (state[1],state[2])

    def done(self, state):
        pass
    
v = VacuumRobot()
print('Test 1:')
inp = [False, True, False, False, True, True, False, False]
ans = v.transduce(inp)
print(ans)

print('Test 2:')
v = VacuumRobot()
inp = [False, False, True, False, False, True, False, True, False, False, False, False]
ans = v.transduce(inp)
print(ans)

print('Test 3:')
v = VacuumRobot()
inp = [False, False, False, True, False, False, True, False, False, True, False, False, False,
False,False, False]
ans = v.transduce(inp)
print(ans)

print('Test 4:')
v = VacuumRobot()
v.start()
inp = [False, True, False, False, True, True, False, False]
state = v.state
for i in inp:
    ns, o = v.get_next_values(state, i)
    state = ns
status = v.state == v.start_state
print('State:', v.state)
print('Not Modified:',status)


