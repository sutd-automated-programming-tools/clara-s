# FINAL EXAM: QUESTION 4


def wordcount (s):
    a = s.split('\n')
    c = []
    for i in a:
        b = i.split()
        d = []
        for i in b:
            if i.isalpha():
                d.append(i)
            for j in i:
                if j in ":,;,.-":
                    i.strip(j)
                d.append(i)
        c.append(d)
    print(c)
    e = []
    f = {}
    for i in c:
        f = {}
        for j in i:
            f[j] = 1
        x = sum(f.values())
        e.append(x)
    for i in range(len(e)):
        if e[i] == 0:
            e[i] = None
    return e
print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 