class Person:
    def __init__(self, name = "Unknown", age = 0, contact_details = {'phone':'+65 0000 0000', 'email':'nobody@nowhere.com.sg'}):
        self.name = name
        self.age = age
        self.contact_details = contact_details
        self.mother = None
        
    def get_name(self):
        return self._name

    def set_name(self, s):
        if len(s) >= 1 and type(s) == str:
            self._name = s
        else:
            self._name = self._name

    def get_age(self):
        return self._age

    def set_age(self, n):
        if type(n) == int:
            if n % 1 == 0:
                if n >= 0:
                    self._age = n
        else:
            self._age = self._age

    def get_email(self):
        return self.contact_details['email']

    def set_email(self, em):
        if type(em) == str:
            if em.count('@') == 1:
                for i in em:
                    if i.isalpha() == False or type(i) != int or i not in ',_':
                        self._contact_details['email'] = self._contact_details['email']
                self._contact_details['email'] = em

   
                    
        

    name = property(get_name, set_name)
    age = property(get_age, set_age)
    email = property(get_email, set_email)
    