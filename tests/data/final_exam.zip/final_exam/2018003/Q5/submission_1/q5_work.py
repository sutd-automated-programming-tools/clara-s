class Person:
    n = {'phone': '+65 0000 0000', 'email': 'nobody@nowhere.com.sg'}
    def __init__(self, name = 'Unknown' , age = 0, contact_details = n, mother = None):
        self.name = name
        self.age = age
        self.contact_details = contact_details
        self.mother = mother
        
    '''getter'''
    def get_name(self):
        return self.name
    
    '''setter: takes care of validity'''
    def set_name(self, inp):
        if isinstance(inp ,str) == True and len(inp) > 1:
            self.name = inp
        else:
            self.name = 'Unknown' 
            
    name = property(get_name, set_name)
    
    '''getter'''
    def get_age(self):
        return self.age
    
    '''setter: takes care of validity'''
    def set_age(self, inp2):
        if isinstance(inp2 ,str) == False:
            self.age = inp2
        else:
            self.age = 0
            
    age = property(get_age, set_age)
    
    def get_email(self):
        return self.contact_details["email"]
    
    '''setter: takes care of validity'''
    def set_email(self, inp3):
        if isinstance(inp3 , str) == True:
            n.update['email': inp3]
        else:
            self.email = n['email']
            
    email = property(get_email, set_email)
    
class mother(Person):
    
    def __init__(self, name):
		mother.__init__(self, name)
    
    def get_mother(self):
        return self.mother
    
    def set_mother(self, m):
        if m != self and p.mother != self:
            return m
        else:
            return Unknown
	
        
        
        
