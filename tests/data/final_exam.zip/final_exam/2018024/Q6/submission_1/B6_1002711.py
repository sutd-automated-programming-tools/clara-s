# -*- coding: utf-8 -*-
"""
Created on Wed May  2 15:19:02 2018

@author: Varun
"""
robot moves up until it hits the top tall, so that the obstacle sensor is output is true. at each pointm, the
output increases by 1 on the y axis
then the robo turns left