class Person:
	def __init__(self, name = 'Unknown', age=  0, contact_details = {'phone': '+65 0000 0000', 'email': 'nobody@nowhere.com.sg'}, mother = None):
		self._name = name
		self._age=  age
		self.contact_details = contact_details
		self.email = contact_details['email']
        self._mother = mother

	def getName(self):
		return self._name

	def setName(self,newName):
		if (len(newName) >= 1) and (type(newName) == str):   	
			self._name = newName
		else:
			self._name 

	def getAge(self):
		return self._age

	def setAge(self, newAge):
		if (type(newAge) == int):
			self._age = newAge
		else:
			self._age 

	def getEmail(self):
		self.email = contact_details['email']
		return self._contact_details['email']

	def setEmail(self, newEmail):
		if type(newEmail) == str:
			for i in range(len(newEmail)):
				if newEmail[i] == '@':
					for i in (newEmail[i+1:len(newEmail)]):
						if i == '.' or i == '_':
							return self.email == newEmail
                        
    def getMother(self):
        return self._mother
    
    def getMother(self, newmother):
        self._mother = newmother

	name = property(getName, setName)
	age = property(getAge, setAge)
    mother = property(getMother, setMother)
