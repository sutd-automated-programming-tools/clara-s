# FINAL EXAM: QUESTION 4

def wordcount (s):    
    lst = []
    
    a = s.split('\n') #splits each new line into an individual index in list
    for i in a: #for every index in list (aka new line)
        if i == " ": 
            lst.append (None)
        else:
            #b = list of individual words
            b = list(i.split()) #split every index (aka new line) into individual words
            index = 0
            counter = 0
            if len(b) > 1 and b != " ": #if more than 1 word in list
                for j in b: #for every word in new line (j = word)
                    if str(j)[index] != str(j)[index + 1]:
                        counter += 1
                    elif j == " ":
                        counter = None
                    else:
                        counter = 1
            elif b == " ":
                lst.append(None)
            else:
                counter = 1
            lst.append(counter)   
    return lst

    '''
    Not done yet:
    - Ignore punctuation characters and treat them as white spaces aka append to list as None
    - Count UNIQUE words: Case sensitive
    '''

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 