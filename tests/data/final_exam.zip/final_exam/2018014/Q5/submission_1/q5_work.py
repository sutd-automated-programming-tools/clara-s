class Person():
    #Task A
    def __init__ (self, name = "Unknown", age = 0, contact_details = {'phone': '+65 0000 0000', 'email': 'nobody@nowhere.com.sg'}):
        self.name = name
        self.age = age
        self.contact_details = contact_details
        
    #Task B
    def name_setter(self, inp):
        if type(inp) == str:
            if len(inp) >= 1:
                self._name = inp
        else:
            pass
    def name_getter(self):
        return self._name
    name = property(name_getter, name_setter)
    
    def age_setter(self, inp):
        if type(inp) == int:
            if inp >= 0:
                self._age = inp
        else:
            pass
    def age_getter(self):
        return self._age
    age = property(age_getter, age_setter)
    
    #Task C
    def email_setter(self, inp):
        if type(inp) == str:
            #if it contains exactly one "@" symbol
                #if all characters are alphanumerical or "." or "_"
                    #if after the "@" symbol, it contains at least one "."
                        self._email = inp
        else:
            pass
    def email_getter(self):
        return self._email
    email = property(email_getter, email_setter)
    
    #Task D
    def mother_setter(self, inp):
        self._mother = inp
    def mother_getter(self):
        return self._mother
    mother = property(mother_getter, mother_setter)