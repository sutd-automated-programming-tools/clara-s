# FINAL EXAM: QUESTION 6

'''
- Robot moves counter clockwise
- Robot completes job after covering all tiles
- Robot stops at the last tile it covers
- Robot always starts at the bottom right and always faces up
- Robot can only move forward
  - If facing up: y-coordinate increase by 1 during next move
  - If facing left: x-coordinate decrease by 1 during next move
- Robot has obstacle sensor that provides Boolean value
  - True = Wall / obstacle
  - False = No wall / obstacle
- Robot position output as tuple (x, y)
'''

from libdw import sm
import copy
class VacuumRobot(sm.SM):
    start_state = None
    displacement = {'up':(0,1), 'left':(-1,0), 'right':(1,0),'down':(0,-1)}
    def get_next_values(self, state, inp):
        pass
        #output = position of robot as a tuple (x,y)
        return next_state, output

    def done(self, state):
        pass
    
v = VacuumRobot()
print('Test 1:')
inp = [False, True, False, False, True, True, False, False]
ans = v.transduce(inp)
print(ans)

print('Test 2:')
v = VacuumRobot()
inp = [False, False, True, False, False, True, False, True, False, False, False, False]
ans = v.transduce(inp)
print(ans)

print('Test 3:')
v = VacuumRobot()
inp = [False, False, False, True, False, False, True, False, False, True, False, False, False,
False,False, False]
ans = v.transduce(inp)
print(ans)

print('Test 4:')
v = VacuumRobot()
v.start()
inp = [False, True, False, False, True, True, False, False]
state = v.state
for i in inp:
    ns, o = v.get_next_values(state, i)
    state = ns
status = v.state == v.start_state
print('State:', v.state)
print('Not Modified:',status)


