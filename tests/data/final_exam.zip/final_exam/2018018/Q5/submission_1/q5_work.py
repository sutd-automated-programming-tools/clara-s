class Person:
    
    __name = 'Unknown'
    __age = 0
    __contact_details = {'phone ':'+65 0000 0000', 'email':'nobody@nowhere.com.sg'}
    
    def __init__(self, name, age, contact_details):
        self.__name = name
        self.__age = age
        self.__contact_details = contact_details
        
    def set_name(self, name):
        self.__name = name
 
    def set_age(self, age):
        self.__age = age
 
    def contact_details(self, contact_details):
        self.__contact_details = contact_details
 
    def get_name(self):
        return self.__name
 
    def get_age(self):
        return str(self.__age)
 
    def get_contact_details(self):
        return str(self.__contact_details)