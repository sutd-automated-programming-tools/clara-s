class Person:

    def __init__(self,name='Unknown',age=0,contact_details={'phone':'+65 0000 0000','email':'nobody@nowhere.com.sg'}):
        
        self._age=age
        self.contact_details=contact_details
        self._name=name
        self.email=self.contact_details['email']

    def getName(self):
        return self._name

    def setName(self,newX):
        if len(newX)>0 and isinstance(newX, str) == True:
            self._name=newX
        else:
            pass
    
    def getAge(self):
        return self._age

    def setAge(self,newX):
        if isinstance(newX, int) == True and newX>=0:
            self._age=newX        
        else:
            pass
    def getEmail(self):
        return self.contact_details['email']

    def setEmail(self,newX):
        
        
        lowc=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
        uppc=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
        digit=['0','1','2','3','4','5','6','7','8','9']
        symbol=['.','_']
        semua=lowc+uppc+digit+symbol
        if isinstance(newX, str) == True:
            text =list(newX)
            
            
            if text.count('@')==1:
                pos=text.index('@')
                if text[pos+1] in semua and text[pos-1] in semua:
                    if '.' in text[pos:]:
                        self.contact_details['email']=newX
                    else:
                        pass
                else:
                    pass
            else:
                pass
                
        else:
            pass
            
            
        
        
    name = property(getName, setName) # property
    age = property(getAge, setAge)
    email= property(getEmail, setEmail)