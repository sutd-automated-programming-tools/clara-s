# FINAL EXAM: QUESTION 4


def wordcount(s):
    a = ''
    word = []
    for i in s:
        if i != ' ' and i != '\n':
            a += i

        elif i == ' ':
            word.append(a)
            a = ''
            
            
    word.append(a)

    answord = []
    total = []
    for i in word:
        if i != '' and i not in answord:
            answord.append(i)
    total.append(len(answord))
    return total

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 