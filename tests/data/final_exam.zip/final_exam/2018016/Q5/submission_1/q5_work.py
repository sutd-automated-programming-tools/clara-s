class Person:
    def __init__(self, name = 'Unknown', age = 0, contact_details = {'phone':'+65 0000 0000', 'email':'nobody@nowhere.com.sg'}):
        self._name = name
        self._age = age
        self.contact_details = contact_details
        
        
    def getname(self):
        return self._name
    
    def setname(self, val):
        if isinstance(val, str) is True and len(val) > 0:
            self._name = val
        else:
            self._name = self._name
            
    def getage(self):
        return self._age
    
    def setage(self, value):
        if isinstance(value, str) is False:
            if int(value) % 2 == 0 or int(value) % 2 == 1:
                self._age = value
        else:
            self._age = self._age
            
    name = property(getname, setname)
    age = property(getage, setage)
    
    
    
    def getdetails(self):
        return self.contact_details['email']
    
    def setdetails(self, mail):
        if mail == '':
            self.contact_details['email'] = self.contact_details['email']

        if isinstance(mail, str) is True:
            if mail.count('@') == 1:
                a = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
                b = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
                c = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '.', '_', '@']
                for i in mail:
                    if i in a or i in b or i in c:
                        index = mail.index('@')
                        for i in mail[index:]:
                            if mail.count('.') >= 1:
                                self.contact_details['email'] = mail
                            else:
                                self.contact_details['email'] = self.contact_details['email']
                    else:
                        self.contact_details['email'] = self.contact_details['email']
            else:
                self.contact_details['email'] = self.contact_details['email']
        else:
            self.contact_details['email'] = self.contact_details['email']
            
    email = property(getdetails, setdetails)