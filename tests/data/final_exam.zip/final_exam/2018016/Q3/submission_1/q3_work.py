#####################
#Starter code for Q3#
#####################

def equity(f):
    p = []
    r = 0
    s = 0
    for k, v in f.items():
        s += v[0]
        r += v[1]
        e = s-r
    p.append(s)
    p.append(r)
    p.append(e)
    x = tuple(map(int, p)) 
    return x

############
#Test cases#
############
f1={'A': [100, 0], 'B': [100, 0], 'C': [100, 0]}
f2={'M': [30, 20], 'N': [50, 70], 'O': [60, 80]}
f3={'J': [0, 30], 'K': [0, 20], 'L': [0, 40]}

print(equity(f1))
print(equity(f2))
print(equity(f3))

