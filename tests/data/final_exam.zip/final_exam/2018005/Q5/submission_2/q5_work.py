          

class Person(object):
    
    def __init__ (self, name = "Unknown", age = 0, contact_details = {'phone': '+65 0000 0000', 'email':'nobody@nowhere.com.sg'}):
        self.name = name
        self.age = age
        self.contact_details = contact_details
        
    def get_name(self):
        return self._name
    
    def set_name(self, inp):
        if isinstance(inp,str) == True  and len(inp) > 1:
            set._name = inp
        else:
            set._name = 'Unknown'
        
    def get_age(self):
        return self._age
    
    def set_age(self, inp):
        if isinstance(inp,int) == True and inp >= 0:
            set._age = inp
        else:
            set._age = 0
            
    def get_email(self):
        return self._contact_details["email"]
    
    def set_email(self,inp):
        self._contact_details["email"] = inp
    
    
# TEST CASES
#   please uncomment to use, and compare
#   the output against that in the printed paper

# Task A Test Code
    
#print('Task A:')
#p = Person()
#print(p.name, p.age)
#print(p.contact_details)
#
#d = {'phone': '+65 8888 8888', 'email': 'chicken@floss.com.sg'}
#p = Person('Charlie the Chicken', 88, d)
#print(p.name, p.age)
#print(p.contact_details)
#
#print()   
    

    
# Task B Test Code
    
print('Task B:')
p = Person()
p.name = ""
print(p.name)

p = Person()
p.age = 88
p.age = 'this is, in fact, a string'
print(p.age)
    
print() 
    
    

# Task C Test Code
    
print('Task C:')
p = Person()
print(p.email)
print(p.email == p.contact_details['email'])

p = Person()
p.email = 'chicken@floss.com.sg'
p.email = 'nasi.kukus'
p.email = 'ayam.goreng@berempah'
p.email = 'sedap!@makanan.com.sg'
print(p.email)
    
print() 



# Task D Test Code
    
#print('Task D:')
#p = Person()
#print(p.mother)
    
#p = Person()
#p.mother = 'Mary Poppins'
#print(p.mother)

#p = Person()
#p.mother = p
#print(p.mother)

#p = Person()
#q = Person('Charlie the Chicken', 88)
#p.mother = q
#print(p.mother.name)

#p = Person()
#q = Person('Charlie the Chicken', 88)
#r = Person('Alison', 22)
#s = Person('Eileen', 55)
#q.mother = r
#r.mother = s
#s.mother = p
#p.mother = q
#print(q.mother.name)
#print(r.mother.name)
#print(s.mother.name)
#print(p.mother)



