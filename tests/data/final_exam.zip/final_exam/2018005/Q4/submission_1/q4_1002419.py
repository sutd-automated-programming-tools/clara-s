# -*- coding: utf-8 -*-

def wordcount (s):
    
    s = s.split()
    
    left_pos = 0
    right_pos = len(s) - 1
    
    while right_pos >= left_pos:
        if not left_pos == right_pos:
            return len(s)
        
p = s.split()

where p[0:1] == "/n" split the word into next line

check if the words are the say by and then return the length of the string if the words are not the same:
    
    while right_pos >= left_pos:
        if not left_pos == right_pos:
            return len(s)
        
if the words are the same:
    
    return left_pos

return the number of words in each line

print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n."))
 
