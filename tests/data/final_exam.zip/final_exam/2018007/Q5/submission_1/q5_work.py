class Person():
    
    def __init__(self,name='Unknown',age=0,contact_details={'phone':'+65 0000 0000','email':'nobody@nowhere.com.sg'},email = 'nobody@nowhere.com.sg'):
        self.name = name
        self.age = age
        self.contact_details = contact_details
        self.email = email
    
    def setter1(self,name):
        if isinstance(name,str) == True and len(name) >= 1:
            self._name = name
    
    def getter1(self):
        return self._name
    
    def setter2(self,age):
        if isinstance(age,int) == True and age >= 0:
            self._age = age
    
    def getter2(self):
        return self._age
    
    name = property(getter1,setter1)
    age = property(getter2,setter2)
    
    def getter3(self):
        return self._email
    
    def setter3(self,cd):
        if isinstance(cd,str) == True:
             count = 0
             for i in range(len(cd)):
                 if cd[i] == '@':
                     count += 1
             if count == 1:
                 index = cd.find('@')
                 for i in range(0,index):
                     if cd[i].isalpha == True or cd[i].isdigit == True or cd[i] == '.' or cd[i] == '_':
                         for j in range(index+1,len(cd)):
                             count1 = 0
                             if cd[i].isalpha == True or cd[i].isdigit == True or cd[i] == '.' or cd[i] == '_':
                                 if cd[i] == '.':
                                     count1 += 1
                                 if count1 >= 1:
                                     self._email =  cd
#                             else:
#                                 return False
#                     else:
#                         return False
#             else:
#                  return False
#        else:
#            return False                                     
    email = property(getter3,setter3) 