# FINAL EXAM: QUESTION 4


def wordcount(s):
    ls = []
    ss = s.split('\n')
    print(ss)
    for i in range(len(ss)):
        st = ss[i].split()
        print(st)
        d = {}
        for j in range(len(st)):
            if st[j] not in d and st[j] != ':' and st[j] != ';' and st[j] != ',' and st[j] != '.' and st[j] != '-':
                d[st[j]] = 1
            elif st[j] in d and st[j] != ':' and st[j] != ';' and st[j] != ',' and st[j] != '.' and st[j] != '-':
                d[st[j]] += 1
        num = len(d.keys())
        if num != 0:
            ls.append(num)
        else:
            ls.append(None)
    
    return ls



print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 