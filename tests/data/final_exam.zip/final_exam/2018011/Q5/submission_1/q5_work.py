class Person:
    pass_init_
    person 'name'
    input age int
    contact_details
    input dict  
    
    