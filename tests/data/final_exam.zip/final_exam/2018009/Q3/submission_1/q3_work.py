#####################
#Starter code for Q3#
#####################

def equity(f):
    total_receivable = 0
    total_payable = 0 
    for i in f:
        x = f[i]
        total_receivable += x[0]
        total_payable += x[1]
    total_net = total_receivable - total_payable
    return total_receivable , total_payable , total_net


############
#Test cases#
############
f1={'A': [100, 0], 'B': [100, 0], 'C': [100, 0]}
f2={'M': [30, 20], 'N': [50, 70], 'O': [60, 80]}
f3={'J': [0, 30], 'K': [0, 20], 'L': [0, 40]}

print(equity(f1))
print(equity(f2))
print(equity(f3))

