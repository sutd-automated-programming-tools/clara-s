# FINAL EXAM: QUESTION 4

def wordcount(s):
    output = [] 
    c = 0 #the word counter
    string = s.split(' ') # splits up the string into a list
    punc = [':',';',',','.','-'] 
    next_line = False #to check if is the next line
    for i in string:
        if next_line == False: 
            #counts the number of words 
            if i == "\n":
                next_line = True
            elif i in punc:
                pass
            else:
                c += 1
        else:
            #append word count,reset the counter, and append None since its a new line
            if c != 0:
                output.append(c) 
                c = 0
            else:
                pass
            next_line = False
            output.append(None)    
    return output
print(wordcount('Tom Dick Harry'))
print(wordcount("Hello world\nHello Hello"))
print(wordcount ("Hello  hello")) 		 
print(wordcount ("Hello  World")) 		 
print(wordcount ("Hello, Hello World"))  
print(wordcount ("Hello \nWorld")) 
print(wordcount ("Hello \nWorld\n")) 		 
print(wordcount ("Hello \n\nWorld")) 	
print(wordcount ("asdasf \n \n \n\nasdasfd;; asfdasd\n Hello hello hello hello world world world"))
print(wordcount ("Hello, world\nHello. Hello\n.")) 