class Person:

    def __init__(self,name= 'Unknown',age=0,d={'phone':'+65 0000 0000','email':'nobody@nowhere.com.sg'}):
        self._name = name
        self._age = age
        self.contact_details = d
        
    def get_name(self):
        return self._name
    
    def set_name(self,value):
        if len(value) > 1 and isinstance (value,str):
            self._name = value
        else:
            self._name = 'Unknown'
        return self._name
    
    def get_age(self):
        return self._age
    def set_age(self,value):
        if isinstance(value,int):
            self._age = value
        else:
            pass
        
    def get_email(self):
        return email
        
    def set_email(self,value):
        c = 0 #the position of @
        z = 0 #number of times "@" appears
        m = 0 # the number of '.' appearing after @
        valid = False
        allowed = 'QWERTYUIOPASDFGHJKLZXCVBNM1234567890.-qwertyuiopasdfghjklzxcvbnm'
        
        for i in value:
            if i =="@":
                break
            else:
                c += 1
                
        for i in value:
            if i == "@":
                z += 1
            else:
                pass
        for i in value:
            if i > c:
                if i == '.':
                    m +=1
                else:
                    pass
                if i in allowed:
                    valid = True
                else:
                    valid = False
            else:
                pass
                
        if isinstance(value,str) and z == 1 and m >= 1 and valid == True:
            return value
        else:
            return "nobody@nowhere.com.sg"
        
    name = property(get_name,set_name)
    age = property(get_age,set_age)
    email = property(get_email,set_email)
#print('Task B:')