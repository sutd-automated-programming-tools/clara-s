def nroot(n,t,num):
    x = 1
    x = round((num)**(1/n), 3)
    return x
print (nroot(2,5,2))

def nroot_complex(n,t,num):
    y = x*1j
    return y
print(nroot_complex(2,5,-4))