def decompose(pence):
    1p = 1*p
    2p = 2*p
    5p = 5*p
    10p = 10*p
    20p = 20*p
    50p = 50*p
    1q = 100*p
    2q = 200*p
    while i <= pence: