# MID-TERM EXAM: QUESTION 7

def decompose(pence):
	ans = pence/1
	return ans