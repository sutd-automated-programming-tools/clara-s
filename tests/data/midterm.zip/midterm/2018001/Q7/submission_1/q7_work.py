# MID-TERM EXAM: QUESTION 7

def decompose(pence):
    pass