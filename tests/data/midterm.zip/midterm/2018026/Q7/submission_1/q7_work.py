# MID-TERM EXAM: QUESTION 7

def decompose(pence):
    return pence
    pass