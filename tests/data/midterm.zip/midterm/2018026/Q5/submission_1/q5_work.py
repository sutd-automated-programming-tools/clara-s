# MID-TERM EXAM: QUESTION 5

import math
import cmath
def nroot(n,t,num):
    return round(math.sqrt(n),3)

def nroot_complex(n,t,num):
    n=nroot(n,t,num)
    return n
    pass