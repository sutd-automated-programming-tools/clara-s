def determinant(matrix):
	pass