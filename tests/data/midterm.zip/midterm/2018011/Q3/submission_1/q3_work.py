# MID-TERM EXAM: QUESTION 3

import math

def area_square(s):
    #psedocode
    area of the square A1= s1^2
    area of the square A2= s2^2

def vol_frustum(top_area, bottom_area, height):
    
    #psedocode
    vol_frustum(top_area, bottom_area, height)=H/3*(A1+A2+(A1*A2)^1/2)
    

def get_volume(s1, s2, height):
    
    #psudocode
    get_volume(s1,s2,height)=H/3*(s1^2+s2^2+(s1^2*s2^2)^1/2)
