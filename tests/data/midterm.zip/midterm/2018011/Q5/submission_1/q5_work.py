# MID-TERM EXAM: QUESTION 5

def nroot(n,t,num):
    x=num
    
    

def nroot_complex(n,t,num):
    pass 