# MID-TERM EXAM: QUESTION 7

def decompose(pence):
    pass2 can be broken down 2 ways
    5 in 3 ways 
    3 5s 3^number of ways