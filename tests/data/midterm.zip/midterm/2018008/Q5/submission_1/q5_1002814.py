def nroot(n,t,num):
    pass

def nroot_complex(n,t,num):
    pass