# MID-TERM EXAM: QUESTION 5
import math
def nroot(n,t,num):
    t = (num)**(n/2)
    return t 

def nroot_complex(n,t,num):
    j = (-1)**0.5
    t = c.math(nroot(n,t,num))
    return t