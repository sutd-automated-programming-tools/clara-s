# MID-TERM EXAM: QUESTION 5

def nroot(n,t,num):
    num = num**(1/n)
    x = nroot(n, i-1, num)
    return x

def nroot_complex(n,t,num):
    pass