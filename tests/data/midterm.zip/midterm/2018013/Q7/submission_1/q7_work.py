# MID-TERM EXAM: QUESTION 7

def decompose(pence):
    if pence==1:
        return 1
    